let math = load("/ext/apps/Scripts/load_api.js");
let result = math.add(5, 10);
print(result);